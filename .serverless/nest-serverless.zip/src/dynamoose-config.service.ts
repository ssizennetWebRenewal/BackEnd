import {
    DynamooseOptionsFactory,
    DynamooseModuleOptions,
  } from 'nestjs-dynamoose';
  
  export class DynamooseConfigService implements DynamooseOptionsFactory {
    createDynamooseOptions(): DynamooseModuleOptions {
      return {
        aws: {
          // .env로 바꿔야
          accessKeyId: 'AKIAXYKJT4X22X33CFHU',
          secretAccessKey: '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',
          region: 'ap-northeast-2',
        },
      };
    }
  }